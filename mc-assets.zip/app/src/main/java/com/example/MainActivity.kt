package com.example

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.OnUserEarnedRewardListener
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class MainActivity : ComponentActivity() {

    private var rewardedAd: RewardedAd? = null
    private var isAdLoading = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Google Mobile Ads SDK
        MobileAds.initialize(this) {}

        // Load first rewarded ad
        loadRewardedAd()

        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        WebViewScreen()
                    }
                }
            }
        }
    }

    private fun loadRewardedAd() {
        if (rewardedAd != null || isAdLoading) return
        isAdLoading = true

        val adRequest = AdRequest.Builder().build()
        // Check if debug or release to decide on Ad Unit ID
        val adUnitId = if (BuildConfig.DEBUG) {
            "ca-app-pub-3940256099942544/5224354917" // Test Rewarded Ad Unit ID
        } else {
            "ca-app-pub-3303988035586005/9477951640" // Real Rewarded Ad Unit ID
        }

        RewardedAd.load(this, adUnitId, adRequest, object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                rewardedAd = null
                isAdLoading = false
                // Fallback to test ad ID if real one fails to load (e.g. during review)
                if (adUnitId != "ca-app-pub-3940256099942544/5224354917") {
                    loadTestRewardedAdFallback()
                }
            }

            override fun onAdLoaded(ad: RewardedAd) {
                rewardedAd = ad
                isAdLoading = false
            }
        })
    }

    private fun loadTestRewardedAdFallback() {
        isAdLoading = true
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(this, "ca-app-pub-3940256099942544/5224354917", adRequest, object : RewardedAdLoadCallback() {
            override fun onAdFailedToLoad(adError: LoadAdError) {
                rewardedAd = null
                isAdLoading = false
            }

            override fun onAdLoaded(ad: RewardedAd) {
                rewardedAd = ad
                isAdLoading = false
            }
        })
    }

    private fun showRewardedAd(webView: WebView) {
        val currentAd = rewardedAd
        if (currentAd != null) {
            currentAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    // Load next ad ahead of time
                    loadRewardedAd()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    rewardedAd = null
                    // Fallback to grant download in case ad display fails
                    grantReward(webView)
                    loadRewardedAd()
                }
            }

            currentAd.show(this, OnUserEarnedRewardListener {
                grantReward(webView)
            })
        } else {
            // If ad is not ready, notify the user.
            Toast.makeText(this, "Ad is loading, please wait...", Toast.LENGTH_SHORT).show()
            if (isAdLoading) {
                // Wait slightly and try showing again or grant download to avoid bad user experience
                webView.postDelayed({
                    val secondaryAd = rewardedAd
                    if (secondaryAd != null) {
                        secondaryAd.show(this, OnUserEarnedRewardListener {
                            grantReward(webView)
                        })
                    } else {
                        Toast.makeText(this, "Ad loading timed out, unlocking download...", Toast.LENGTH_SHORT).show()
                        grantReward(webView)
                    }
                }, 2000)
            } else {
                // If it isn't loading and not loaded, trigger a reload and let them download
                grantReward(webView)
                loadRewardedAd()
            }
        }
    }

    private fun grantReward(webView: WebView) {
        webView.post {
            webView.evaluateJavascript("javascript:rewardUserAndDownload();", null)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Composable
    fun WebViewScreen() {
        var webViewInstance by remember { mutableStateOf<WebView?>(null) }

        BackHandler(enabled = true) {
            val wv = webViewInstance
            if (wv != null && wv.canGoBack()) {
                wv.goBack()
            } else {
                finish()
            }
        }

        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                WebView(context).apply {
                    webViewInstance = this
                    
                    isVerticalScrollBarEnabled = false
                    isHorizontalScrollBarEnabled = false
                    
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                        allowFileAccess = true
                        allowContentAccess = true
                    }

                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                        }
                    }

                    webChromeClient = WebChromeClient()

                    // Register custom bridge name matching app.js expectations
                    addJavascriptInterface(object {
                        @JavascriptInterface
                        fun showRewardedAd() {
                            post {
                                this@MainActivity.showRewardedAd(this@apply)
                            }
                        }
                    }, "AndroidBridge")

                    loadUrl("file:///android_asset/index.html")
                }
            },
            update = {
                webViewInstance = it
            }
        )
    }
}
